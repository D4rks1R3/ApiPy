from django.db import models
from django.db.models import fields
from  rest_framework import serializers
from rest_framework.fields import ReadOnlyField
from Api_App.models import Users
#Serializador apra formatar os dados e entregar todos em json 


class UserSerializer(serializers.ModelSerializer):
	ser = serializers.HyperlinkedRelatedField(many=True, read_only=True, view_name='Users-detail')
	class Meta:
		models = Users
		fields = ['name', 'cnpj',]
