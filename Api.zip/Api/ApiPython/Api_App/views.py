from django.shortcuts import render
from django.http import HttpResponse, response
from Api_App.models import Users
from Api_App.serializers import UserSerializer
from rest_framework import serializers


def index(request):
    query = Users.objects.all()
    return HttpResponse(query)


# Create your views here.

