from django.db import models


# Create your models here.

class Users(models.Model):
	#Tabela de usuarios 
	name = models.CharField(max_length=20)
	cnpj = models.CharField(max_length=20)

	def __str__(self):
		self.list =  list()
		self.list.pop(self.name)
		self.list.pop(self.cnpj)
		return str(self.list[0:1])

class UsersAndress(models.Model):
	#tabelas de endereço
	rua = models.CharField(max_length=20)
	bairro = models.CharField(max_length=20)
	CidadeDeEstado = models.CharField(max_length=20)
	complemento = models.CharField(max_length=20)

	def __str__(self):
		return self.rua

class UsersProjects(models.Model):
	#TAbela de projetos
	NameProject = models.CharField(max_length=20)
	codigo = models.CharField(max_length=20)
	valor_money = models.CharField(max_length=20)

	def __str__(self):
		return self.NameProject